import java.io.*;

public class Twoindextriangle_Mercado{
    public static void main(String args []) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));


        for (int i= 5-1; i>=0 ; i--)
        {
            for (int j=0; j<=i; j++)
            {
            System.out.print("*" );
            }
            System.out.println();
            }




    }
}        